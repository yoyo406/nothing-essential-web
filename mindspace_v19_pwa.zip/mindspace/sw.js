/* ═══════════════════════════════════════════════════════════
   Mind Space — Service Worker v2
   Stratégie : Cache-first pour assets locaux + fonts Google
               Network-first pour tout le reste
═══════════════════════════════════════════════════════════ */
const CACHE_NAME = 'mindspace-v2';

// Ressources à mettre en cache à l'installation
const PRECACHE_URLS = [
  './',
  './index.html',
  './manifest.json',
  './icon-192.png',
  './icon-512.png',
];

// Domaines traités en cache-first (polices Google)
const CACHE_FIRST_ORIGINS = [
  'fonts.googleapis.com',
  'fonts.gstatic.com',
];

/* ── Installation : précache ── */
self.addEventListener('install', function (e) {
  self.skipWaiting(); // activation immédiate
  e.waitUntil(
    caches.open(CACHE_NAME).then(function (cache) {
      // Précache des assets locaux (tolerant aux erreurs)
      return Promise.all(
        PRECACHE_URLS.map(function (url) {
          return cache.add(url).catch(function () {
            // Silencieux si un fichier local est introuvable
          });
        })
      );
    })
  );
});

/* ── Activation : nettoyage ancien cache ── */
self.addEventListener('activate', function (e) {
  e.waitUntil(
    caches.keys().then(function (keys) {
      return Promise.all(
        keys
          .filter(function (k) { return k !== CACHE_NAME; })
          .map(function (k) { return caches.delete(k); })
      );
    }).then(function () {
      return clients.claim(); // contrôle immédiat de tous les onglets
    })
  );
});

/* ── Fetch : stratégie hybride ── */
self.addEventListener('fetch', function (e) {
  var url = new URL(e.request.url);

  // Ignorer les requêtes non-GET
  if (e.request.method !== 'GET') return;

  // Cache-first pour les polices Google
  var isFontRequest = CACHE_FIRST_ORIGINS.some(function (origin) {
    return url.hostname.includes(origin);
  });

  if (isFontRequest) {
    e.respondWith(
      caches.open(CACHE_NAME).then(function (cache) {
        return cache.match(e.request).then(function (cached) {
          if (cached) return cached;
          return fetch(e.request, { mode: 'no-cors' }).then(function (response) {
            if (response) cache.put(e.request, response.clone());
            return response;
          }).catch(function () {
            return new Response('', { status: 503 });
          });
        });
      })
    );
    return;
  }

  // Cache-first pour les assets locaux (index.html, icons, manifest)
  var isLocalAsset = url.origin === self.location.origin;
  if (isLocalAsset) {
    e.respondWith(
      caches.open(CACHE_NAME).then(function (cache) {
        return cache.match(e.request).then(function (cached) {
          // Revalider en arrière-plan (stale-while-revalidate)
          var networkFetch = fetch(e.request).then(function (response) {
            if (response && response.status === 200) {
              cache.put(e.request, response.clone());
            }
            return response;
          }).catch(function () { return null; });

          return cached || networkFetch;
        });
      })
    );
    return;
  }

  // Network-first pour tout le reste
  e.respondWith(
    fetch(e.request).catch(function () {
      return caches.match(e.request).then(function (cached) {
        return cached || new Response('Hors-ligne — Mind Space', {
          status: 503,
          headers: { 'Content-Type': 'text/plain; charset=utf-8' }
        });
      });
    })
  );
});
